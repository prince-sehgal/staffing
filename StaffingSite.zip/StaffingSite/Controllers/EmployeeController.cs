﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StaffingSite.Models;
using System.IO;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Configuration;
using StaffingSite.MongoDB;
using MongoDB.Bson;

namespace StaffingSite.Controllers
{
    public class EmployeeController : Controller
    {
        public MongoDBConnector Connector;
        public EmployeeController()
        {
            this.Connector = new MongoDBConnector();
        }
        public ActionResult Index(string JobId)
        {
            //Session["UserID"] = "59845c13a3a77448a866ecdf";
            if (Session["UserID"] != null)
            {
                Session["globalJobId"] = JobId;
                Positions position = new Positions();
                position.jobid = Convert.ToString(Session["globalJobId"]);
                List<Positions> Positions = Connector.GetDatabase().GetCollection<Positions>("position").FindAll().ToList();
                Positions = (from data in Positions where DateTime.ParseExact(data.edate, "dd/MM/yyyy", null) >= DateTime.Today select data).ToList();
                position.positions = new SelectList(Positions, "_id", "title");
                Session["model"] = position;

                return View(Session["model"]);
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }

        public ActionResult Candidate(Int64 CandidateId)
        {
            Positions position = new Positions();
            position.jobid = Convert.ToString(Session["globalJobId"]);
            List<Positions> Positions = Connector.GetDatabase().GetCollection<Positions>("position").FindAll().ToList();
            Positions = (from data in Positions where DateTime.ParseExact(data.edate, "dd/MM/yyyy", null) >= DateTime.Today select data).ToList();
            position.positions = new SelectList(Positions, "_id", "title");

            Session["CandidateId"] = CandidateId;
            IMongoQuery query = Query.And(
                    Query.EQ("referenceid",  new BsonInt64(CandidateId)),
                     Query.EQ("referedby", new BsonString(Session["UserID"].ToString()))
                 );


            ReferredList list = Connector.GetDatabase().GetCollection<ReferredList>("candidate").Find(query).FirstOrDefault();
            if (list != null)
            {
                position.firstname = list.firstname;
                position.midname = list.lastname;
                position.IsFemale = list.IsFemale;
                position.jobid = list.jobid;
                position.lastname = list.lastname;
                position.dob = list.dob;
                position.primaryskill = list.primaryskill;
                position.secondaryskill = list.secondaryskill;
                position.currentexp = list.currentexp;
                position.totalexp = list.totalexp;
                position.currentlocation = list.currentlocation;
                position.preferredlocation = list.preferredlocation;
                position.emailid = list.emailid;
                position.mobile = list.mobile;
                Session["CandidateFile"] = list.attachment;
                if (list.statusid <= 0)
                {
                    Session["isCandidateEditable"] = "true";
                }
                else {
                    Session["isCandidateEditable"] = "false";
                }
                Session["model"] = position;

                return View(Session["model"]);
            }
            else
            {
                return RedirectToAction("History");
            }
        }

        [HttpPost]
        public JsonResult IsDiversityPosition(string PositionId) 
        {
            var result = Connector.GetDatabase().GetCollection<Positions>("position").FindOne(Query.EQ("_id", ObjectId.Parse(PositionId)));
            return Json(result.Diversity_Position, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult CheckValidEmail(string emailId,string jobId)
        {
            MongoDatabase objDatabse = Connector.GetDatabase();
            IMongoQuery query = Query.And(
                     Query.EQ("emailid", new BsonString(emailId)),
                      Query.EQ("jobid", new BsonString(jobId))
                  );

            string statusText = "Available";
            //IMongoUpdate updateQuery = Update.Set("statusid", StatusCode);
            ReferredList user = objDatabse.GetCollection<ReferredList>("candidate").Find(query).SingleOrDefault();
            if(user != null)
            {
                statusText = "Not Available";
            }
            return Json(statusText, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult CheckValidPhone(string phone, string jobId)
        {
            MongoDatabase objDatabse = Connector.GetDatabase();
            IMongoQuery query = Query.And(
                     Query.EQ("mobile", new BsonString(phone)),
                      Query.EQ("jobid", new BsonString(jobId))
                  );

            string statusText = "Available";
            //IMongoUpdate updateQuery = Update.Set("statusid", StatusCode);
            ReferredList user = objDatabse.GetCollection<ReferredList>("candidate").Find(query).SingleOrDefault();
            if (user != null)
            {
                statusText = "Not Available";
            }
            return Json(statusText, JsonRequestBehavior.AllowGet);
        }
        public ActionResult History()
        {
            if (Session["UserID"] != null)
            {
                try
                {
                    UserProfile profile = new UserProfile();
                   
                    var result = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("_id", ObjectId.Parse(Session["UserID"].ToString())));
                    profile.isactive = result.isactive;
                    profile.name = result.name;
                    profile._id = result._id;
                    profile.photo = result.photo;
                    profile.lob = result.lob;
                    profile.ReferedCandidatesList = Connector.GetDatabase().GetCollection<ReferredList>("candidate").Find(Query.EQ("referedby", Session["UserID"].ToString())).ToList();
                    foreach (ReferredList candidate in profile.ReferedCandidatesList)
                    {
                        var job = Connector.GetDatabase().GetCollection<Positions>("position").FindOne(Query.EQ("_id", ObjectId.Parse(candidate.jobid)));
                        candidate.designation = job.designation;
                        candidate.taleonumber = job.taleonumber;
                    }
                    return View(profile);
                }
                catch (Exception ex)
                {
                    ViewBag.Message = ex.Message;
                    return View();
                }
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateCandidate(Positions position, HttpPostedFileBase AttachedFile)
        {
            try
            {
                candidate obj = new candidate();

                if (AttachedFile != null)
                {
                    string fileName = Session["CandidateFile"].ToString();
                    AttachedFile.SaveAs(Path.Combine(Server.MapPath("~/Attachments"), fileName));
                }

                MongoDatabase objDatabse = Connector.GetDatabase();
                IMongoQuery query = Query.And(
                  Query.EQ("referenceid", new BsonInt64(long.Parse(Session["CandidateId"].ToString()))),
                   Query.EQ("referedby", new BsonString(Session["UserID"].ToString()))
               );
                //IMongoQuery query = Query.EQ("taleonumber", new BsonString(Session["WorkDayId"].ToString()));
                IMongoUpdate updateQuery = Update.Set("dob", position.dob)
                                                .Set("primaryskill", position.primaryskill)
                                                .Set("secondaryskill", position.secondaryskill)
                                                .Set("totalexp", position.totalexp)
                                                .Set("currentexp", position.currentexp)
                                                .Set("currentlocation", position.currentlocation)
                                                .Set("preferredlocation", position.preferredlocation);

                objDatabse.GetCollection<ReferredList>("candidate").FindAndModify(query, SortBy.Null, updateQuery);
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error! Please try again" + ex.Message;
                return View();
            }
            return RedirectToAction("History");
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(string JobId, Positions position, HttpPostedFileBase PostedFile)
        {
            //Console.WriteLine(Request.QueryString["JobId"]);
            if (Session["globalJobId"] != null && Session["globalJobId"].ToString() != "")
                position.jobid = string.Format("{0}", Session["globalJobId"]);
            if (PostedFile == null)
            {
                ModelState.AddModelError("CustomError", "Please attach CV");
                return View(Session["model"]);
            }
            var supportedTypes = new[] { "doc", "docx", "pdf" };
            var fileExt = System.IO.Path.GetExtension(PostedFile.FileName).Substring(1);
            if (!supportedTypes.Contains(fileExt))
            //if (!(cvfile.ContentType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||cvfile.ContentType == "application/pdf"))
            {
                ModelState.AddModelError("CustomError", "Only word document and pdf file allowed");
                return View(Session["model"]);
            }
            try
            {
                candidate obj = new candidate();
                string fileName = Guid.NewGuid() + Path.GetExtension(PostedFile.FileName);
                PostedFile.SaveAs(Path.Combine(Server.MapPath("~/Attachments"), fileName));
              

                long ReferenceId = Connector.GetDatabase().GetCollection<candidate>("candidate").Count() + long.Parse(ConfigurationManager.AppSettings["InitialCount"]) + 1;
                MongoCollection<candidate> collection = Connector.GetDatabase().GetCollection<candidate>("candidate");
                BsonDocument candidate = new BsonDocument
                                                 {  
                                                        {"jobid",position.jobid},  
                                                        {"firstname",position.firstname},  
                                                        {"midname",position.midname ?? ""},  
                                                        {"lastname",position.lastname},  
                                                        {"dob",position.dob},  
                                                        {"primaryskill",position.primaryskill},  
                                                        {"secondaryskill",position.secondaryskill},  
                                                        {"totalexp",position.totalexp},  
                                                        {"currentexp",position.currentexp},  
                                                        {"currentlocation",position.currentlocation},
                                                        {"preferredlocation",position.preferredlocation},
                                                        {"referedby",Session["userid"].ToString()},  
                                                        //{"lob",position.lob},
                                                        //{"sublob",position.sublob},
                                                         {"lob",0},
                                                        {"sublob",0},
                                                        //{"taleonumber",position.taleonumber},
                                                        {"mobile",position.mobile},  
                                                        {"emailid", position.emailid.ToLower()},
                                                        {"attachment", fileName},
                                                        {"referedon",DateTime.Now},
                                                        {"referenceid",ReferenceId},
                                                        {"IsFemale",position.IsFemale},
                                                        {"statusid",0}
                                                 };
                collection.Insert(candidate);
                ModelState.Clear();
                position.jobid = string.Format("{0}", Session["globalJobId"]);
                ViewBag.Message = "Candidate Details has been saved with reference id - " + ReferenceId + ".";
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error! Please try again" + ex.Message;
                return View(Session["model"]);
            }
            return View(Session["model"]);
        }
    }
}
