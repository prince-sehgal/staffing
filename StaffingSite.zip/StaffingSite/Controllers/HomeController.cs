﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StaffingSite.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Core;
using MongoDB.Driver.Builders;
using System.Configuration;   
using StaffingSite.MongoDB;
using System.Threading.Tasks;

namespace StaffingSite.Controllers
{
    public class HomeController : Controller
    {
        public MongoDBConnector Connector;
        public HomeController()
        {
            this.Connector = new MongoDBConnector();
        }
        private List<UserProfile> _UserList = new List<UserProfile>();

        public ActionResult Login()
        {
            try
            {
                string NetworkId = System.Web.HttpContext.Current.User.Identity.Name;
                var result = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("username", NetworkId.Substring(NetworkId.IndexOf("\\") + 1).ToLower()));
                if (result != null && Boolean.Parse(result.isactive))
                {
                    Session["UserID"] = result._id;
                    Session["UserType"] = result.usertype;
                    Session["lob"] = result.lob;
                    Session["name"] = result.name;
                    Session["employeeid"] = result.employeeid;
                    Session["photo"] = result.photo;
                    if (result.usertype == "0")
                        return RedirectToAction("Hr");
                    else if (result.usertype == "1")
                        return RedirectToAction("Dashboard");
                    return View();
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View();
            }    
        }
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
        [HttpPost]
        public ActionResult Login(UserProfile objUser)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var result = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("username", objUser.username.ToLower()));
                    if (result != null && Boolean.Parse(result.isactive))
                    {
                        if (result.password == objUser.password)
                        {
                            objUser.isactive = result.isactive;
                            objUser.name = result.name;
                            objUser._id = result._id;
                            objUser.photo = result.photo;
                            objUser.lob = result.lob;
                            Session["UserID"] = objUser._id;
                            Session["UserType"] = result.usertype;
                            Session["lob"] = result.lob;
                            Session["name"] = result.name;
                            Session["employeeid"] = result.employeeid; 
                            Session["photo"] = result.photo;
                            if (result.usertype == "0")
                                return RedirectToAction("Hr");
                            else if (result.usertype == "1")
                                return RedirectToAction("Dashboard");
                            return View();
                        }
                        else
                        {
                            ViewBag.Message = "Please verify your credentials.";
                            return View();
                        }
                    }
                    else
                    {
                        ViewBag.Message = "Please verify your credentials.";
                        return View();
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Message = ex.Message;
                    return View();
                }     
            }
            return View();
        }
        public ActionResult SelectStatus()
        {

            
            return View();
        }

        public ActionResult Hr()
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "0")
            {
                try
                {
                    UserProfile profile = new UserProfile();
                    var result = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("_id", ObjectId.Parse(Session["UserID"].ToString())));
                    profile.isactive = result.isactive;
                    profile.name = result.name;
                    profile._id = result._id;
                    profile.photo = result.photo;
                    profile.lob = result.lob;
                    profile.employeeid = result.employeeid;
                    //profile.list = Connector.GetDatabase().GetCollection<Positions>("position").FindAll().ToList();
                    profile.list = Connector.GetDatabase().GetCollection<Positions>("position").Find(Query.EQ("publishedby", Session["UserID"].ToString())).ToList();
                    foreach (Positions position in profile.list)
                    {
                        position.headcount = Connector.GetDatabase().GetCollection<ReferredList>("candidate").Find(Query.EQ("jobid", Convert.ToString(position._id))).ToList().Count;
                    }
                    List<SelectListItem> items = new List<SelectListItem>();
                    items.Add(new SelectListItem { Text = "To be evaluated", Value = "0" });
                    items.Add(new SelectListItem { Text = "CV shortlisted", Value = "1" });
                    items.Add(new SelectListItem { Text = "HR Shortlisted", Value = "2" });
                    items.Add(new SelectListItem { Text = "HR Rejected", Value = "3" });
                    items.Add(new SelectListItem { Text = "Operations Interview shortlisted", Value = "4" });
                    items.Add(new SelectListItem { Text = "Operations Interview rejected", Value = "5" });
                    items.Add(new SelectListItem { Text = "Profile on Hold", Value = "6" });
                    items.Add(new SelectListItem { Text = "Position on Hold", Value = "7" });
                    items.Add(new SelectListItem { Text = "To be offered", Value = "8" });
                    items.Add(new SelectListItem { Text = "Offered", Value = "9" });
                    items.Add(new SelectListItem { Text = "Joined", Value = "10" });
                    items.Add(new SelectListItem { Text = "Not Joined", Value = "11" });
                    //items.Add(new SelectListItem { Text = "In Process", Value = "0" });
                    //items.Add(new SelectListItem { Text = "Hr Discussion", Value = "1" });
                    //items.Add(new SelectListItem { Text = "Short Listed", Value = "2" });
                    //items.Add(new SelectListItem { Text = "Operation Round", Value = "3" });
                    //items.Add(new SelectListItem { Text = "Rejected", Value = "3" });
                    //items.Add(new SelectListItem { Text = "To be Offered", Value = "3" });
                    //items.Add(new SelectListItem { Text = "Offered", Value = "3" });
                    //items.Add(new SelectListItem { Text = "Join", Value = "3" });
                    ViewBag.StatusType = items;
                    return View(profile);
                }
                catch (Exception ex)
                {
                      ViewBag.Message = ex.Message;
                      return View();
                }     
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        public ActionResult Position(string workdayId)
        {
            Session["WorkDayId"] = workdayId;
            Positions position = new Positions();
            try
            {
                if (Session["WorkDayId"] != null)
                {
                    MongoDatabase objDatabse = Connector.GetDatabase();
                    IMongoQuery query = Query.EQ("taleonumber", new BsonString(Session["WorkDayId"].ToString()));

                    Positions data = objDatabse.GetCollection<Positions>("position").Find(query).SingleOrDefault();
                    position.taleonumber = data.taleonumber;
                    position.sdate = data.sdate;
                    position.edate = data.edate;
                    position.grade = data.grade;
                    position.Diversity_Position = data.Diversity_Position;
                    position.designation = data.designation;
                    position.currentexp = data.currentexp;
                    position.currentlocation = data.currentlocation;
                    position.lob = data.lob;
                    position.worklocation = data.worklocation;
                    position.modeofinterview = data.modeofinterview;
                    position.RecruiterName = data.RecruiterName;
                    position.IsFemale = data.IsFemale;
                    position.Skills = data.Skills;
                    position.InterviewDetails = data.InterviewDetails;
                    position.shift = data.shift;
                    position.role = data.role;
                    string []worklocations = position.worklocation.Split(',');
                    foreach (string location in worklocations)
                    {
                        if (location.Trim() == "ASF")
                            position.ASF = true;
                        if (location.Trim() == "Gurgaon")
                            position.Gurgaon = true;
                        if (location.Trim() == "Noida")
                            position.Noida = true;
                    }
                }
                position.Shifts = new SelectList(getShifts().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
                position.Grades = new SelectList(getGrades().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
                position.lobs = new SelectList(getLobs().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
                
                
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error! Please try again" + ex.Message;
                return View(position);
            }
            return View(position);
        }
        public ActionResult ApplyPosition(string workdayId)
        {
            Session["WorkDayId"] = workdayId;
            Positions position = new Positions();
            try
            {
                if (Session["WorkDayId"] != null)
                {
                    MongoDatabase objDatabse = Connector.GetDatabase();
                    IMongoQuery query = Query.EQ("taleonumber", new BsonString(Session["WorkDayId"].ToString()));

                    Positions data = objDatabse.GetCollection<Positions>("position").Find(query).SingleOrDefault();
                    position.taleonumber = data.taleonumber;
                    position.sdate = data.sdate;
                    position.edate = data.edate;
                    position.grade = data.grade;
                    position.designation = data.designation;
                    position.currentexp = data.currentexp;
                    position.currentlocation = data.currentlocation;
                    position.lob = data.lob;
                    position.worklocation = data.worklocation;
                    position.RecruiterName = data.RecruiterName;
                    position.modeofinterview = data.modeofinterview;
                    position.Skills = data.Skills;
                    position.InterviewDetails = data.InterviewDetails;
                    position.shift = data.shift;
                    position.role = data.role;
                    Session["PositionId"] = data._id;
                }
                position.Shifts = new SelectList(getShifts().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error! Please try again" + ex.Message;
                return View(position);
            }
            return View(position);
        }
        [HttpPost]
        [ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Position(Positions position)
        {
            position.Shifts = new SelectList(getShifts().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
            position.Grades = new SelectList(getGrades().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
            position.lobs = new SelectList(getLobs().Select(s => new SelectListItem() { Value = s.Name }), "Value", "Value");
            position.worklocation = concatWorkLocation(position);
                try
                {
                if (Session["WorkDayId"] == null)
                {
                    if (Connector.GetDatabase().GetCollection<Positions>("position").Find(Query.EQ("taleonumber", position.taleonumber)).ToList().Count > 0)
                    {
                        ViewBag.Message = "Error: Workday ID already exists, please enter a unique Workday ID.";
                        return View(position);
                    }
                    else
                    {
                        MongoCollection<Positions> collection = Connector.GetDatabase().GetCollection<Positions>("position");
                        BsonDocument newPosition = new BsonDocument
                                                     {
                                                            {"taleonumber",position.taleonumber},
                                                            {"grade",position.grade},
                                                            {"designation",position.designation},
                                                            {"Diversity_Position",position.Diversity_Position},
                                                            {"lob",position.lob},
                                                            {"worklocation",position.worklocation},
                                                            {"shift",position.shift},
                                                            {"modeofinterview",position.modeofinterview},
                                                            {"RecruiterName",position.RecruiterName},
                                                            {"role",position.role == null ? string.Empty : position.role},
                                                            {"Skills",position.Skills == null ? string.Empty : position.Skills},
                                                            {"InterviewDetails",position.InterviewDetails == null ? string.Empty : position.InterviewDetails},
                                                            {"sdate",position.sdate},
                                                            {"edate",position.edate},
                                                            {"publishedby",Session["userid"].ToString()},
                                                            {"publishedon",DateTime.Now}
                                                     };
                        collection.Insert(newPosition);
                        ModelState.Clear();
                        ViewBag.Message = "Position has been published in Employee's Dashboard";
                        position.taleonumber = position.designation = position.lob = position.worklocation = position.role = position.Skills = position.sdate = position.edate = position.InterviewDetails = position.RecruiterName =  position.modeofinterview  = position.grade = "";
                        position.shift = "Select";
                        position.ASF = position.Gurgaon = position.Noida = false;
                        return View(position);
                    }
                }
                else
                {
                    position.taleonumber = Session["WorkDayId"].ToString();
                    MongoDatabase objDatabse = Connector.GetDatabase();
                    IMongoQuery query = Query.EQ("taleonumber", new BsonString(Session["WorkDayId"].ToString()));

                    IMongoUpdate updateQuery = Update.Set("designation", position.designation)
                                                    .Set("grade", position.grade)
                                                    .Set("Diversity_Position", position.Diversity_Position)
                                                    .Set("lob", position.lob)
                                                    .Set("worklocation", position.worklocation)
                                                    .Set("shift", position.shift)
                                                    .Set("modeofinterview", position.modeofinterview)
                                                    .Set("RecruiterName", position.RecruiterName)
                                                    .Set("role", position.role)
                                                    .Set("InterviewDetails", position.InterviewDetails)
                                                    .Set("Skills", position.Skills)
                                                    .Set("sdate", position.sdate)
                                                    .Set("edate", position.edate)
                                                    .Set("publishedon", DateTime.Now);

                    objDatabse.GetCollection<ReferredList>("position").FindAndModify(query, SortBy.Null, updateQuery);

                    position.taleonumber = Session["WorkDayId"].ToString();
                    ViewBag.Message = "Position has been re-published in Employee's Dashboard";
                    return View(position);
                }
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "Error! Please try again" + ex.Message;
                    return View(position);
                }
         
        
        }
        private string concatWorkLocation(Positions position) 
        {
            string WorkLocation = string.Empty;
            if (position.ASF)
                WorkLocation += "ASF, ";
            if (position.Gurgaon)
                WorkLocation += "Gurgaon, ";
            if (position.Noida)
                WorkLocation += "Noida, ";
            if (WorkLocation.Length > 2)
                return WorkLocation.Substring(0, WorkLocation.Length - 2);
            else
                return string.Empty;
        }
        //static async Task upateStatus()
        //{
        //    //  var result = Connector.GetDatabase().GetCollection<ReferredList>("candidate").FindOne(Query.EQ("referenceid", new BsonInt64(CandidateId)));

        //    //if (result != null)
        //    //{
        //    //    result.statusid = StatusCode;
        //    //    Connector.GetDatabase().GetCollection<ReferredList>("candidate").Update(Query.EQ("referenceid", Convert.ToString(CandidateId)), (IMongoUpdate)result);


        //    var conString = "mongodb://localhost:27017";
        //    var Client = new MongoClient(conString);
        //    var DB = new MongoDBConnector().GetDatabase();
        //    var collection = DB.GetCollection<BsonDocument>("candidate");

        //    //find the MasterID with 1130 and replace it with 1120
        //    var result = await collection.FindOneAndUpdateAsync(
        //                        Builders<BsonDocument>.Filter.Eq("MasterID", 1110),
        //                        Builders<BsonDocument>.Update.Set("MasterID", 1120)
        //                        );
        //    //retrive the data from collection
        //    await collection.Find(new BsonDocument())
        //     .ForEachAsync(x => Console.WriteLine(x));

        //}
        [HttpPost]
        public JsonResult AddCandidateStatus(Int64 CandidateId, Int64 StatusId, string Feedback)
        {
            try
            {
                MongoDatabase objDatabse = Connector.GetDatabase();
                IMongoQuery query = Query.EQ("referenceid", new BsonInt64(CandidateId));
                IMongoUpdate updateQuery = Update.Set("statusid", StatusId);
                objDatabse.GetCollection<ReferredList>("candidate").FindAndModify(query, SortBy.Null, updateQuery);

                MongoCollection<CandidateFeedback> collection = Connector.GetDatabase().GetCollection<CandidateFeedback>("feedback");
                BsonDocument newFeedback = new BsonDocument
                                                     {
                                                            {"CandidateId",CandidateId},
                                                            {"StatusId",StatusId},
                                                            {"Feedback",Feedback},
                                                            {"SavedBy",Session["userid"].ToString()},
                                                            {"HrName",Session["name"].ToString()},
                                                            {"SavedOn",DateTime.Now},
                                                            {"DateString",DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt")}
                                                     };
                collection.Insert(newFeedback);
                return Json("success", JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("error", JsonRequestBehavior.AllowGet);
            }

        }
        [HttpPost]
        public JsonResult GetCandidateStatus(Int64 CandidateId)
        {
            try
            {
                MongoDatabase objDatabse = Connector.GetDatabase();
                IMongoQuery query = Query.And(
                         Query.EQ("CandidateId", new BsonInt64(CandidateId)),
                          Query.EQ("SavedBy", new BsonString(Session["userid"].ToString()))
                      );
                List<CandidateFeedback> collection = objDatabse.GetCollection<CandidateFeedback>("feedback").Find(query).ToList();

                var result = Connector.GetDatabase().GetCollection<ReferredList>("candidate").FindOne(Query.EQ("referenceid", CandidateId));
                
                string referenceId = result.referedby;
                var referenceObj = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("_id", ObjectId.Parse(referenceId)));

                CandidateLead lead = new CandidateLead() { 
                 employeeid = referenceObj.employeeid,
                 name = referenceObj.name,
                 lob = referenceObj.lob
                };
                query = Query.And(
                          Query.EQ("mobile", new BsonString(result.mobile)),
                          Query.EQ("emailid", new BsonString(result.emailid.ToLower()))
                      );
                List<ReferredList> refferedCollection = objDatabse.GetCollection<ReferredList>("candidate").Find(query).ToList();

                List<InspectCandidate> CandidatureList = new List<InspectCandidate>();
                foreach (ReferredList item in refferedCollection)
                {
                    var job = Connector.GetDatabase().GetCollection<Positions>("position").FindOne(Query.EQ("_id", ObjectId.Parse(item.jobid)));
                    CandidatureList.Add(new InspectCandidate() { 
                     PositionTitle = job.designation,
                     StatusId = item.statusid,
                     WorkdayId = job.taleonumber
                    });
                }

                CandidateData data = new CandidateData()
                {
                    Feedbacks = collection.OrderByDescending(m => m.SavedOn).ToList(),
                    Candidature = CandidatureList,
                    Reference = lead

                };
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("error", JsonRequestBehavior.AllowGet);
            }

        }
        
        [HttpPost]
        public JsonResult GetCandidateInfo(Int64 CandidateId)
        {
            var result = Connector.GetDatabase().GetCollection<ReferredList>("candidate").FindOne(Query.EQ("referenceid", CandidateId));
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult UpdateCandidateStatus(Int64 CandidateId, int StatusCode)
        {
            MongoDatabase objDatabse = Connector.GetDatabase();
            IMongoQuery query = Query.EQ("referenceid", new BsonInt64(CandidateId));

            IMongoUpdate updateQuery = Update.Set("statusid", StatusCode);
            //ReferredList user = objDatabse.GetCollection<ReferredList>("candidate").Find(query).SingleOrDefault();
            //objDatabse.GetCollection("candidate").Update(query, updateQuery);


            objDatabse.GetCollection<ReferredList>("candidate").FindAndModify(query, SortBy.Null, updateQuery);


            string statusText = "Status updated for Ref.No.: " + CandidateId;
            return Json(statusText, JsonRequestBehavior.AllowGet);
        }
        public ActionResult CandidateAction(string ReferenceId)
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "0")
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        public ActionResult Applications(string PositionId)
        {
            if (Session["UserID"] != null)
            {
                try
                {
                    UserProfile profile = new UserProfile();
                    var result = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("_id", ObjectId.Parse(Session["UserID"].ToString())));
                    profile.isactive = result.isactive;
                    profile.name = result.name;
                    profile._id = result._id;
                    profile.photo = result.photo;
                    profile.lob = result.lob;
                    profile.ReferedCandidatesList = Connector.GetDatabase().GetCollection<ReferredList>("candidate").Find(Query.EQ("jobid", Convert.ToString(PositionId))).ToList();

                    var job = Connector.GetDatabase().GetCollection<Positions>("position").FindOne(Query.EQ("_id", ObjectId.Parse(PositionId)));
                    profile.taleonumber = job.taleonumber;
                    return View(profile);
                }
                catch (Exception ex)
                {
                    ViewBag.Message = ex.Message;
                    return View();
                }
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        public FileResult DownloadCV(string CurrentFileName, string CandidateName)
        {
            string contentType = string.Empty;

            if (CurrentFileName.Contains(".pdf"))
            {
                contentType = "application/pdf";
                CandidateName += ".pdf";
            }
            else if (CurrentFileName.Contains(".doc"))
            {
                contentType = "application/docx";
                CandidateName += ".doc";
            }
            else if (CurrentFileName.Contains(".docx"))
            {
                contentType = "application/docx";
                CandidateName += ".docx";
            }
            return File(string.Format(@"~\Attachments\{0}", CurrentFileName), contentType, CandidateName);   
        }
        public ActionResult Dashboard()
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "1")
            {
                try
                {
                    UserProfile profile = new UserProfile();
                    var result = Connector.GetDatabase().GetCollection<UserProfile>("UserProfile").FindOne(Query.EQ("_id", ObjectId.Parse(Session["UserID"].ToString())));
                    profile.isactive = result.isactive;
                    profile.name = result.name;
                    profile._id = result._id;
                    profile.photo = result.photo;
                    profile.lob = result.lob;
                    profile.employeeid = result.employeeid;
                    profile.list = Connector.GetDatabase().GetCollection<Positions>("position").FindAll().ToList();
                    //profile.list = (from data in profile.list where DateTime.ParseExact(data.edate, "dd/MM/yyyy", null) >= DateTime.Today select data).ToList();
                    
                    return View(profile);
                }
                catch (Exception ex)
                {
                    ViewBag.Message = ex.Message;
                    return View();
                }
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        private List<Grade> getGrades()
        {
            string[] grades = { "B1", "B2", "C1", "C2", "D1", "D2", "E", "F", "G", "H" };
            List<Grade> GradeList = new List<Grade>();
            for (int i = 0; i < grades.Length; i++)
            {
                GradeList.Add(
                 new Grade()
                 {
                     id = i,
                     Name = grades[i]
                 });
            }
            return GradeList;
        }
        private List<Lob> getLobs()
        {
            string [] lobs = {"Health","RPA","Talent","Finance","GTI","MMC Functions","	F&A","US H&B","WAS"};
            List<Lob> LobList = new List<Lob>();
            for (int i = 0; i < lobs.Length; i++)
            {
                LobList.Add(
                 new Lob()
                 {
                     id = i,
                     Name = lobs[i]
                 });
            }
            return LobList;
        }
        private List<Shift> getShifts()
        {
            return new List<Shift>(){
                        new Shift(){
                             Name ="08:00 AM to 05:00 PM"
                        },
                        new Shift(){
                             Name ="11:30 AM to 08:30 PM"
                        },
                        new Shift(){
                             Name ="01:00 PM to 10:00 PM"
                        }
                    };
        }

    }
}
